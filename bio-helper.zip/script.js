
const data = {
  "митоз": "Митоз – жасушаның бөліну процесі. Бұл процесс 5 кезеңнен тұрады...",
  "днқ": "ДНҚ – тұқымқуалаушылық ақпаратты тасымалдайтын молекула...",
  "хлоропласт": "Хлоропласт – фотосинтез жүретін органелла..."
};

document.getElementById('searchInput').addEventListener('input', function() {
  const query = this.value.toLowerCase();
  const resultDiv = document.getElementById('results');
  resultDiv.innerHTML = data[query] ? `<p>${data[query]}</p>` : '<p>Материал табылмады.</p>';
});
